package org.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.claims.dao.AuthenticationDaoImpl;
import org.cts.claims.dao.Authentication_Dao;
import org.cts.claims.dao.ClaimDaoImpl;
import org.cts.claims.model.Authentication;
import org.cts.claims.model.Claim;

/**
 * Servlet implementation class AddUserServlet
 */
 @WebServlet("/autoInvest")
 public class AutoInvestController  extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ClaimDaoImpl dao = new ClaimDaoImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int claimId=Integer.parseInt(request.getParameter("claimId"));
		String date=request.getParameter("year");
		String stat = request.getParameter("claimType");
//		int claimId=Integer.parseInt(request.getParameter("year"));
//		int cId=Integer.parseInt(request.getParameter("CId"));
//		double subClaimAmt=Double.parseDouble(request.getParameter("subClaimAmt"));
//		double salRecAmt=Double.parseDouble(request.getParameter("salRecAmt"));
		 Claim claim = 	dao.getClaim(claimId);
		 
		 claim.setClaim_set_date(date);
		 claim.setStatus("settled");
		
			String msg=dao.insert(claim);
			pw.println("<script>alert(msg);</script>");
		
		
		response.sendRedirect("adjuster.jsp");
	}
}


