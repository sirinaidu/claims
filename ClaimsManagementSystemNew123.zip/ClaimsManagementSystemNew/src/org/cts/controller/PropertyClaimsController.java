package org.cts.controller;

	import java.io.IOException;
	import java.io.PrintWriter;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

import org.cts.claims.dao.ClaimDaoImpl;
import org.cts.claims.dao.ClaimsInfoDao;
import org.cts.claims.dao.ClaimsInfoDaoImpl;
import org.cts.claims.model.Claim;
import org.cts.claims.model.ClaimsInfo;

	@WebServlet("/propertyClaims")
	public class PropertyClaimsController extends HttpServlet {
		private static final long serialVersionUID = 1L;
		ClaimDaoImpl dao2 = new ClaimDaoImpl();
		ClaimsInfoDao dao=new ClaimsInfoDaoImpl();
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
			PrintWriter pw=response.getWriter();
			int claimId=Integer.parseInt(request.getParameter("claimid"));
			int customerId=Integer.parseInt(request.getParameter("customerid"));
			String status="Reported";
			String date = request.getParameter("claim_set_date");
			double claimsetamt=Double.parseDouble(request.getParameter("claimsetamt"));
			int propertyclaimsId=Integer.parseInt(request.getParameter("propclaimsid"));
			int policy_Id=Integer.parseInt(request.getParameter("policyid"));
			String cause=request.getParameter("cause");
			String policev=request.getParameter("policev");
			String firedpt=request.getParameter("firedpt");
			String steps=request.getParameter("steps");
			String details=request.getParameter("details");
			ClaimsInfo claimsInfo = new ClaimsInfo(propertyclaimsId, cause, policev, firedpt, steps, details);
			Claim claim = new Claim(claimId, customerId,"Auto",status,date,claimsetamt, 0,0, policy_Id, propertyclaimsId);
			String msg=dao.insertClaimsInfo(claimsInfo);
			String msg1=dao2.insertPropertyClaim(claim);
			pw.println("<script>alert(msg);</script>");
		    response.sendRedirect("csr.jsp");
		}

	}

