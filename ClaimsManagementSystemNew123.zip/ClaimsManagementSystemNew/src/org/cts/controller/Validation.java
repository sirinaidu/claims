package org.cts.controller;

import java.util.regex.Pattern;

public class Validation {
	
	boolean validateString(String text) {
		String pattern = "[a-zA-Z]";
		if(Pattern.matches(pattern, text))
			return true;
		
		return false;
	}

}
